import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider, useAppContext } from './context/AppContext';
import { Layout } from './components/Layout';
import { Login } from './pages/Login';
import { AdminDashboard } from './pages/AdminDashboard';
import { Tasks } from './pages/Tasks';
import { EmployeeDashboard } from './pages/EmployeeDashboard';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';

const ProtectedRoute = ({ children, allowedRole }: { children: React.ReactNode, allowedRole: string }) => {
  const { currentUser } = useAppContext();
  
  if (!currentUser) return <Navigate to="/" replace />;
  if (currentUser.role !== allowedRole) {
    return <Navigate to={currentUser.role === 'admin' ? '/admin' : '/employee'} replace />;
  }
  
  return <>{children}</>;
};

const AppRoutes = () => {
  const { currentUser } = useAppContext();

  return (
    <Routes>
      <Route path="/" element={currentUser ? <Navigate to={currentUser.role === 'admin' ? '/admin' : '/employee'} /> : <Login />} />
      
      <Route element={<Layout />}>
        {/* Admin Routes */}
        <Route path="/admin" element={
          <ProtectedRoute allowedRole="admin"><AdminDashboard /></ProtectedRoute>
        } />
        <Route path="/admin/tasks" element={
          <ProtectedRoute allowedRole="admin"><Tasks /></ProtectedRoute>
        } />
        <Route path="/admin/reports" element={
          <ProtectedRoute allowedRole="admin"><Reports /></ProtectedRoute>
        } />
        <Route path="/admin/settings" element={
          <ProtectedRoute allowedRole="admin"><Settings /></ProtectedRoute>
        } />

        {/* Employee Routes */}
        <Route path="/employee" element={
          <ProtectedRoute allowedRole="employee"><EmployeeDashboard /></ProtectedRoute>
        } />
      </Route>
    </Routes>
  );
};

function App() {
  return (
    <AppProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AppProvider>
  );
}

export default App;
