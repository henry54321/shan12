import React, { createContext, useContext, useState } from 'react';
import { User, Task, Notification, TaskStatus } from '../types';
import { mockUsers, mockTasks, mockNotifications } from '../data/mock';

interface AppContextType {
  currentUser: User | null;
  users: User[];
  tasks: Task[];
  notifications: Notification[];
  companyName: string;
  login: (userId: string) => void;
  logout: () => void;
  addTask: (task: Omit<Task, 'id' | 'createdAt'>) => void;
  updateTaskStatus: (taskId: string, status: TaskStatus) => void;
  markNotificationsRead: () => void;
  setCompanyName: (name: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users] = useState<User[]>(mockUsers);
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [companyName, setCompanyName] = useState<string>('Job Schedule System');

  const login = (userId: string) => {
    const user = users.find(u => u.id === userId);
    if (user) setCurrentUser(user);
  };

  const logout = () => setCurrentUser(null);

  const addTask = (newTaskData: Omit<Task, 'id' | 'createdAt'>) => {
    const newTask: Task = {
      ...newTaskData,
      id: `t${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setTasks(prev => [...prev, newTask]);

    // Notify assignee
    if (newTask.assigneeId) {
      const assignee = users.find(u => u.id === newTask.assigneeId);
      if (assignee) {
        setNotifications(prev => [{
          id: `n${Date.now()}`,
          userId: newTask.assigneeId!,
          message: `You have been assigned a new task: "${newTask.title}"`,
          read: false,
          createdAt: new Date().toISOString(),
        }, ...prev]);
      }
    }
  };

  const updateTaskStatus = (taskId: string, status: TaskStatus) => {
    setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status } : t));
    
    // Notify admins if task is completed
    if (status === 'completed') {
      const task = tasks.find(t => t.id === taskId);
      const admins = users.filter(u => u.role === 'admin');
      
      const newNotifs = admins.map(admin => ({
        id: `n${Date.now()}-${admin.id}`,
        userId: admin.id,
        message: `${currentUser?.name} completed task: "${task?.title}"`,
        read: false,
        createdAt: new Date().toISOString(),
      }));
      
      setNotifications(prev => [...newNotifs, ...prev]);
    }
  };

  const markNotificationsRead = () => {
    if (!currentUser) return;
    setNotifications(prev => prev.map(n => n.userId === currentUser.id ? { ...n, read: true } : n));
  };

  return (
    <AppContext.Provider value={{
      currentUser, users, tasks, notifications, companyName,
      login, logout, addTask, updateTaskStatus, markNotificationsRead, setCompanyName
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within an AppProvider');
  return context;
};
