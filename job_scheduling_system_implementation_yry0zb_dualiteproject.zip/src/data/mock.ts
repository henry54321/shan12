import { User, Task, Notification } from '../types';

export const mockUsers: User[] = [
  { id: 'u1', name: 'Alice Admin', role: 'admin', avatar: 'https://i.pravatar.cc/150?u=u1' },
  { id: 'u2', name: 'Bob Manager', role: 'admin', avatar: 'https://i.pravatar.cc/150?u=u2' },
  { id: 'u3', name: 'Charlie Worker', role: 'employee', avatar: 'https://i.pravatar.cc/150?u=u3' },
  { id: 'u4', name: 'Diana Staff', role: 'employee', avatar: 'https://i.pravatar.cc/150?u=u4' },
  { id: 'u5', name: 'Evan Employee', role: 'employee', avatar: 'https://i.pravatar.cc/150?u=u5' },
];

export const mockTasks: Task[] = [
  {
    id: 't1',
    title: 'Update Server Infrastructure',
    description: 'Migrate legacy servers to the new cloud architecture.',
    assigneeId: 'u3',
    status: 'in-progress',
    priority: 'high',
    dueDate: new Date(Date.now() + 86400000 * 2).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: 't2',
    title: 'Design New Landing Page',
    description: 'Create wireframes and high-fidelity mockups for the Q3 marketing campaign.',
    assigneeId: 'u4',
    status: 'todo',
    priority: 'medium',
    dueDate: new Date(Date.now() + 86400000 * 5).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 't3',
    title: 'Fix Authentication Bug',
    description: 'Users are reporting intermittent logout issues on mobile devices.',
    assigneeId: 'u3',
    status: 'completed',
    priority: 'high',
    dueDate: new Date(Date.now() - 86400000 * 1).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 10).toISOString(),
  },
  {
    id: 't4',
    title: 'Quarterly Report Generation',
    description: 'Compile financial and productivity reports for the board meeting.',
    assigneeId: 'u5',
    status: 'todo',
    priority: 'low',
    dueDate: new Date(Date.now() + 86400000 * 7).toISOString(),
    createdAt: new Date().toISOString(),
  },
];

export const mockNotifications: Notification[] = [
  {
    id: 'n1',
    userId: 'u1',
    message: 'Charlie Worker completed "Fix Authentication Bug"',
    read: false,
    createdAt: new Date().toISOString(),
  }
];
