import React, { useState } from 'react';
import { useAppContext } from '../context/AppContext';
import { Save, Building2 } from 'lucide-react';

export const Settings: React.FC = () => {
  const { companyName, setCompanyName } = useAppContext();
  const [name, setName] = useState(companyName);
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setCompanyName(name);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">System Options</h1>
        <p className="text-gray-500">Manage your organization's settings and preferences.</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
        <div className="flex items-center gap-3 mb-6 pb-4 border-b border-gray-100">
          <div className="p-2 bg-indigo-50 rounded-lg">
            <Building2 className="w-5 h-5 text-indigo-600" />
          </div>
          <h2 className="text-lg font-semibold text-gray-900">Organization Details</h2>
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="max-w-md">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Company Name
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-shadow"
              placeholder="Enter company name"
            />
            <p className="mt-2 text-sm text-gray-500">
              This name will be displayed in the sidebar and reports.
            </p>
          </div>

          <div className="pt-4 flex items-center gap-4">
            <button
              type="submit"
              className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition-colors shadow-sm"
            >
              <Save className="w-4 h-4" />
              Save Changes
            </button>
            
            {isSaved && (
              <span className="text-sm text-emerald-600 font-medium animate-pulse">
                Successfully saved!
              </span>
            )}
          </div>
        </form>
      </div>
    </div>
  );
};
