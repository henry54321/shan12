import React from 'react';
import { useAppContext } from '../context/AppContext';
import ReactECharts from 'echarts-for-react';

export const Reports: React.FC = () => {
  const { tasks, users } = useAppContext();
  const employees = users.filter(u => u.role === 'employee');

  // Prepare data for Employee Workload Chart
  const workloadData = employees.map(emp => {
    const empTasks = tasks.filter(t => t.assigneeId === emp.id);
    return {
      name: emp.name.split(' ')[0],
      completed: empTasks.filter(t => t.status === 'completed').length,
      pending: empTasks.filter(t => t.status !== 'completed').length,
    };
  });

  const workloadOption = {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['Completed', 'Pending'] },
    grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
    xAxis: { type: 'value' },
    yAxis: { type: 'category', data: workloadData.map(d => d.name) },
    series: [
      {
        name: 'Completed',
        type: 'bar',
        stack: 'total',
        label: { show: true },
        emphasis: { focus: 'series' },
        itemStyle: { color: '#10B981' },
        data: workloadData.map(d => d.completed)
      },
      {
        name: 'Pending',
        type: 'bar',
        stack: 'total',
        label: { show: true },
        emphasis: { focus: 'series' },
        itemStyle: { color: '#F59E0B' },
        data: workloadData.map(d => d.pending)
      }
    ]
  };

  // Prepare data for Priority Distribution
  const priorityData = [
    { value: tasks.filter(t => t.priority === 'high').length, name: 'High' },
    { value: tasks.filter(t => t.priority === 'medium').length, name: 'Medium' },
    { value: tasks.filter(t => t.priority === 'low').length, name: 'Low' },
  ];

  const priorityOption = {
    tooltip: { trigger: 'item' },
    legend: { top: 'bottom' },
    color: ['#EF4444', '#F59E0B', '#3B82F6'],
    series: [
      {
        name: 'Priority',
        type: 'pie',
        radius: '50%',
        data: priorityData,
        emphasis: {
          itemStyle: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0, 0, 0, 0.5)' }
        }
      }
    ]
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Productivity Reports</h1>
        <p className="text-gray-500">Analyze team performance and task distribution.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Employee Workload & Completion</h3>
          <ReactECharts option={workloadOption} style={{ height: '400px' }} />
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Task Priority Distribution</h3>
          <ReactECharts option={priorityOption} style={{ height: '400px' }} />
        </div>
      </div>
    </div>
  );
};
