import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { CheckSquare, Users, ShieldAlert } from 'lucide-react';

export const Login: React.FC = () => {
  const { users, login, companyName } = useAppContext();
  const navigate = useNavigate();

  const handleLogin = (userId: string, role: string) => {
    login(userId);
    if (role === 'admin') navigate('/admin');
    else navigate('/employee');
  };

  const admins = users.filter(u => u.role === 'admin');
  const employees = users.filter(u => u.role === 'employee');

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
            <CheckSquare className="w-10 h-10 text-white" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          {companyName}
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Select a mock user account to continue
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10 space-y-6">
          
          <div>
            <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2 mb-4">
              <ShieldAlert className="w-5 h-5 text-indigo-500" />
              Administrators
            </h3>
            <div className="space-y-3">
              {admins.map(user => (
                <button
                  key={user.id}
                  onClick={() => handleLogin(user.id, user.role)}
                  className="w-full flex items-center gap-4 p-3 border border-gray-200 rounded-lg hover:border-indigo-500 hover:bg-indigo-50 transition-colors text-left"
                >
                  <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                  <div>
                    <p className="font-medium text-gray-900">{user.name}</p>
                    <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 flex items-center gap-2 mb-4">
              <Users className="w-5 h-5 text-green-500" />
              Employees
            </h3>
            <div className="space-y-3">
              {employees.map(user => (
                <button
                  key={user.id}
                  onClick={() => handleLogin(user.id, user.role)}
                  className="w-full flex items-center gap-4 p-3 border border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors text-left"
                >
                  <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                  <div>
                    <p className="font-medium text-gray-900">{user.name}</p>
                    <p className="text-xs text-gray-500 capitalize">{user.role}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
