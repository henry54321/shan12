import React from 'react';
import { useAppContext } from '../context/AppContext';
import { TaskCard } from '../components/TaskCard';

export const EmployeeDashboard: React.FC = () => {
  const { tasks, currentUser, updateTaskStatus } = useAppContext();

  if (!currentUser) return null;

  const myTasks = tasks.filter(t => t.assigneeId === currentUser.id);

  const columns = [
    { id: 'todo', title: 'To Do', color: 'bg-gray-100' },
    { id: 'in-progress', title: 'In Progress', color: 'bg-blue-50' },
    { id: 'completed', title: 'Completed', color: 'bg-emerald-50' },
  ];

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">My Tasks</h1>
        <p className="text-gray-500">Manage your assigned work and update statuses.</p>
      </div>

      {/* Kanban Board */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-6 overflow-hidden">
        {columns.map(col => (
          <div key={col.id} className={`${col.color} rounded-xl p-4 flex flex-col h-full border border-gray-200/60`}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-700">{col.title}</h3>
              <span className="bg-white text-gray-600 text-xs font-bold px-2 py-1 rounded-full shadow-sm">
                {myTasks.filter(t => t.status === col.id).length}
              </span>
            </div>
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 custom-scrollbar">
              {myTasks.filter(t => t.status === col.id).map(task => (
                <TaskCard 
                  key={task.id} 
                  task={task} 
                  showAssignee={false}
                  onStatusChange={updateTaskStatus}
                />
              ))}
              {myTasks.filter(t => t.status === col.id).length === 0 && (
                <div className="text-center p-4 text-sm text-gray-400 border-2 border-dashed border-gray-300 rounded-lg">
                  No tasks here
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
