import React from 'react';
import { useAppContext } from '../context/AppContext';
import { CheckCircle2, Clock, AlertCircle, Users } from 'lucide-react';
import ReactECharts from 'echarts-for-react';

export const AdminDashboard: React.FC = () => {
  const { tasks, users } = useAppContext();

  const stats = {
    total: tasks.length,
    completed: tasks.filter(t => t.status === 'completed').length,
    inProgress: tasks.filter(t => t.status === 'in-progress').length,
    todo: tasks.filter(t => t.status === 'todo').length,
    employees: users.filter(u => u.role === 'employee').length,
  };

  const statusChartOption = {
    tooltip: { trigger: 'item' },
    legend: { top: '5%', left: 'center' },
    color: ['#10B981', '#3B82F6', '#F59E0B'],
    series: [
      {
        name: 'Tasks',
        type: 'pie',
        radius: ['40%', '70%'],
        avoidLabelOverlap: false,
        itemStyle: { borderRadius: 10, borderColor: '#fff', borderWidth: 2 },
        label: { show: false, position: 'center' },
        emphasis: {
          label: { show: true, fontSize: 20, fontWeight: 'bold' }
        },
        labelLine: { show: false },
        data: [
          { value: stats.completed, name: 'Completed' },
          { value: stats.inProgress, name: 'In Progress' },
          { value: stats.todo, name: 'To Do' }
        ]
      }
    ]
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
        <p className="text-gray-500">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Tasks" value={stats.total} icon={CheckCircle2} color="text-indigo-600" bg="bg-indigo-100" />
        <StatCard title="Completed" value={stats.completed} icon={CheckCircle2} color="text-emerald-600" bg="bg-emerald-100" />
        <StatCard title="In Progress" value={stats.inProgress} icon={Clock} color="text-blue-600" bg="bg-blue-100" />
        <StatCard title="Active Employees" value={stats.employees} icon={Users} color="text-purple-600" bg="bg-purple-100" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Task Status Distribution</h3>
          <ReactECharts option={statusChartOption} style={{ height: '300px' }} />
        </div>

        {/* Recent Activity or High Priority Tasks */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-red-500" />
            High Priority Tasks
          </h3>
          <div className="space-y-4">
            {tasks.filter(t => t.priority === 'high' && t.status !== 'completed').slice(0, 4).map(task => (
              <div key={task.id} className="flex items-start gap-4 p-3 rounded-lg hover:bg-gray-50 border border-gray-100">
                <div className="w-2 h-2 mt-2 rounded-full bg-red-500 shrink-0" />
                <div>
                  <p className="font-medium text-gray-900 text-sm">{task.title}</p>
                  <p className="text-xs text-gray-500 mt-1">Due: {new Date(task.dueDate).toLocaleDateString()}</p>
                </div>
              </div>
            ))}
            {tasks.filter(t => t.priority === 'high' && t.status !== 'completed').length === 0 && (
              <p className="text-gray-500 text-sm text-center py-4">No high priority tasks pending.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ title, value, icon: Icon, color, bg }: any) => (
  <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 flex items-center gap-4">
    <div className={`p-3 rounded-lg ${bg}`}>
      <Icon className={`w-6 h-6 ${color}`} />
    </div>
    <div>
      <p className="text-sm font-medium text-gray-500">{title}</p>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
    </div>
  </div>
);
