import React from 'react';
import { Task } from '../types';
import { useAppContext } from '../context/AppContext';
import { format } from 'date-fns';
import { Clock, AlertCircle } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  showAssignee?: boolean;
  onStatusChange?: (taskId: string, newStatus: Task['status']) => void;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task, showAssignee = true, onStatusChange }) => {
  const { users } = useAppContext();
  const assignee = users.find(u => u.id === task.assigneeId);

  const priorityColors = {
    low: 'bg-blue-100 text-blue-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-red-100 text-red-800',
  };

  const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';

  return (
    <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-2">
        <span className={`text-xs font-medium px-2.5 py-0.5 rounded-full capitalize ${priorityColors[task.priority]}`}>
          {task.priority}
        </span>
        {onStatusChange && (
          <select
            value={task.status}
            onChange={(e) => onStatusChange(task.id, e.target.value as Task['status'])}
            className="text-xs border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            <option value="todo">To Do</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>
        )}
      </div>
      
      <h4 className="font-semibold text-gray-900 mb-1">{task.title}</h4>
      <p className="text-sm text-gray-500 line-clamp-2 mb-4">{task.description}</p>
      
      <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
        <div className="flex items-center gap-4">
          {showAssignee && assignee && (
            <div className="flex items-center gap-2" title={`Assigned to ${assignee.name}`}>
              <img src={assignee.avatar} alt={assignee.name} className="w-6 h-6 rounded-full" />
              <span className="text-xs text-gray-600 hidden sm:inline-block">{assignee.name.split(' ')[0]}</span>
            </div>
          )}
          
          <div className={`flex items-center gap-1 text-xs ${isOverdue ? 'text-red-600 font-medium' : 'text-gray-500'}`}>
            {isOverdue ? <AlertCircle className="w-3.5 h-3.5" /> : <Clock className="w-3.5 h-3.5" />}
            {format(new Date(task.dueDate), 'MMM d')}
          </div>
        </div>
      </div>
    </div>
  );
};
